// import './style.scss';
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faSearch, faCartShopping, faHeart } from "@fortawesome/free-solid-svg-icons";
// import { useState, useEffect } from "react";
// import './style-slider.scss';
// import axios from "axios";
// //import { useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { Navigate } from "react-router-dom";
// import { findAllAsync } from "./reducers/productreducer";
// import { useCart } from 'react-use-cart'

// const CRUDProduct = () => {
// //     const { updateItemQuantity } = useCart();

// return (
//         <div className='container-fluid py-3'>
//             <div className='row justify-content-center'>
//                 {/* <h2 className="text-center py-3 text-decoration-underline">My Cart</h2>
//                 <div className='col-sm-12 col-md-12 col-lg-8 col-xl-8 col-xxl-8 py-4'></div>
//                 <div className='d-flex justify-content-center shadow py-3'>
//                     <p className='position-relative fw-bolder text-title fs-5'>Cart<span className="position absolute translate-middle rounded-pill badge bg-danger left-3 mx-2"></span></p>
//                 </div>
//                 <div> */}
//             </div>
//             <div className='row justify-content-center'>
//                 <table className='table table-hover m-0'>
//                     <tbody>
//                         <tr> <div className='align-middle'>


//                             <td> <img src="" className='img-cart' /></td>

//                             <td>     </td>
//                             <td> </td>

//                             <td>

//                                 <button onClick={() => updateItemQuantity} className='btn btn-outline-dark' ms-1>-</button>
//                             </td>
//                             <td>
//                                 <button onClick={() => updateItemQuantity} className='btn btn-outline-dark' ms-1>+</button>
//                             </td>
//                             <td>
//                                 <button onClick={() => updateItemQuantity} className='btn btn-outline-danger' ms-5>Remove Item</button>


//                             </td>



//                             <td> 200</td>


//                         </div>
//                         </tr>

//                     </tbody>
//                 </table>
//                 {/* </div> */}
//                 <table class="table table-hover m-50">
//                     <thead>
//                         <tr>
//                             <th>Firstname</th>
//                             <th>Lastname</th>
//                             <th>Email</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         <tr>
//                             <td>   <img src="" className='img-cart' /></td>

//                             <td>Baju Kantoran</td>
//                             <td> Rp. 100.000</td>
//                             <td> <button onClick={() => updateItemQuantity} className='btn btn-outline-dark' ms-1>-</button>
//                                  <button onClick={() => updateItemQuantity} className='btn btn-outline-dark' ms-1>+</button>
//                                  <button onClick={() => updateItemQuantity} className='btn btn-outline-danger' ms-5>Remove Item</button>
//                             </td>
//                             <td>
//                             <input type="number" class="form-control" name=""  defaultValue="" required >
//                             </input>
//                             </td>
//                         </tr>
//                         <tr>
//                             <td>Mary</td>
//                             <td>Moe</td>
//                             <td>mary@example.com</td>
//                         </tr>
//                         <tr>
//                             <td>July</td>
//                             <td>Dooley</td>
//                             <td>july@example.com</td>
//                         </tr>
//                     </tbody>
//                 </table>
//             </div>

//         </div>
//         <div className="col-6">
//            <div className="card">
//                   <img src={item.product.image} height="100px" width="100px" />
//           </div>
//           <ul>
//           <li>{item.product.name}</li>
//           <li>{item.quantity} <input type="number" class="form-control" name=""  onChange={updatequantity(item.id)} defaultValue={item.quantity} required >
//                         </input></li>
//           <li>{item.product.price}</li>
//             </ul>
//         </div>
      
//       <div className="col-2">
//         <button>
//         <FontAwesomeIcon icon={faPlus} />
//         </button>
//       </div>
//       <div className="col-2">
//         <FontAwesomeIcon icon={faMinus} />
//       </div>
//      <div className="col-1">
//          <FontAwesomeIcon icon={faTrashCan} />
//      </div>





 
{/* <div className="row">

<div className="col-1">
  <label>
    <input className={"input-addtocart"} type={"checkbox"} />
  </label>
</div>
</div>
)
}

export default CRUDProduct; */}